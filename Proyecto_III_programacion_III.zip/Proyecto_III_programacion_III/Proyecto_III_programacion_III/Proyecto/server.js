// Importa las librerías necesarias
const express = require('express');  // Express es un framework para crear servidores web
const sql = require('mssql');        // mssql es una librería para conectarse a bases de datos SQL Server
const app = express();               // Inicializa una aplicación de Express
const port = 3000;                   // Define el puerto donde correrá el servidor

// Middleware para procesar los datos del formulario
app.use(express.urlencoded({ extended: true }));  // Habilita la capacidad de Express para analizar datos de formularios enviados como URL-encoded
app.use(express.json());                          // Habilita la capacidad de Express para analizar datos en formato JSON

// Configuración de conexión a SQL Server
const config = {
  server: 'PAPAYITAS',  // Nombre del servidor SQL al que te conectas
  database: 'DB_Boleta',  // Nombre de la base de datos a la que quieres conectarte
  options: {
    trustServerCertificate: true,  // Requerido si trabajas en local (ignora certificados)
    trustedConnection: true,       // Usa autenticación de Windows para conectarse
  },
  port: 1433  // Puerto predeterminado de SQL Server
};

// Conectar a la base de datos SQL Server
sql.connect(config).then(() => {
  console.log('Conectado a la base de datos SQL Server');
}).catch((err) => {
  console.log('Error al conectar a la base de datos:', err);  // Si hay un error, muestra el mensaje
});

// Ruta para manejar el envío de un formulario y guardar los datos en la base de datos
app.post('/guardar-boleta', (req, res) => {
  const { nombre, email, telefono, fecha, servicio } = req.body;  // Extrae los datos del cuerpo del formulario enviado

  // Crea una nueva solicitud a la base de datos
  const request = new sql.Request();
  
  // Define una consulta SQL para insertar los datos en la tabla 'Boletas'
  const query = `
    INSERT INTO Boletas (Nombre, Email, Telefono, Fecha, Servicio)
    VALUES ('${nombre}', '${email}', '${telefono}', '${fecha}', '${servicio}')
  `;

  // Ejecuta la consulta SQL
  request.query(query, (err, result) => {
    if (err) {
      // Si hay un error al ejecutar la consulta, muestra el error y envía una respuesta de error
      console.error('Error al guardar la boleta:', err);
      res.status(500).send('Error al guardar la boleta');
    } else {
      // Si la consulta se ejecuta con éxito, envía una respuesta de éxito
      res.status(200).send('Boleta guardada correctamente');
    }
  });
});

// Otra ruta para manejar el envío de datos del formulario con campos adicionales
app.post('/guardar-boleta', (req, res) => {
  const { numeroDeBoleta, cliente, modelo, serie, tecnico } = req.body;  // Extrae los datos enviados en el cuerpo del formulario

  // Crea una nueva solicitud a la base de datos
  const request = new sql.Request();
  
  // Define una consulta SQL para insertar los datos en la tabla 'infoclient'
  const query = `
    INSERT INTO infoclient (cliente, idtecnico, fecha, modelo, serie, boleta_nro)
    VALUES ('${cliente}', '${tecnico}', GETDATE(), '${modelo}', '${serie}', '${numeroDeBoleta}')
  `;

  // Ejecuta la consulta SQL
  request.query(query, (err, result) => {
    if (err) {
      // Si hay un error al ejecutar la consulta, muestra el error y envía una respuesta de error
      console.error('Error al guardar la boleta:', err);
      res.status(500).send('Error al guardar la boleta');
    } else {
      // Si la consulta se ejecuta con éxito, envía una respuesta de éxito
      res.status(200).send('Boleta guardada correctamente');
    }
  });
});

// Iniciar el servidor en el puerto 3000
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

