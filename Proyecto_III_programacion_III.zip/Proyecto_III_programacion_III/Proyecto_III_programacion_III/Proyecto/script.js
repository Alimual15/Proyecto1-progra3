const formulario = document.getElementById('formularioDeTicketDeServicio');
const botonFirma = document.getElementById('boton-firma');
const botonSello = document.getElementById('boton-sello');
const campoFirma = document.getElementById('firma');
const campoSello = document.getElementById('sello');

// Agregar eventos de clic para los botones de firma y sello
botonFirma.addEventListener('click', () => {
    const nombre = prompt('Ingrese su nombre para firmar:');
    if (nombre) {
        campoFirma.value = `Firma de ${nombre}`;
    }
});

botonSello.addEventListener('click', () => {
    campoSello.value = 'Sello agregado';
});
//Evento para agregar el sello
botonSello.addEventListener('click', () => {
    campoSello.value = 'Sello agregado';
});

// Agregar evento de envío para el formulario
formulario.addEventListener('submit', (e) => {
    e.preventDefault();

    // Validar información del cliente
    const cliente = document.getElementById('cliente').value.trim();
    if (!cliente) {
        alert('Por favor, ingrese el nombre del cliente');
        return;
    }

    // Validar modelo y serie
    const modelo = document.getElementById('modelo').value.trim();
    const serie = document.getElementById('serie').value.trim();
    if (!modelo || !serie) {
        alert('Por favor, ingrese el modelo y serie del equipo');
        return;
    }

    // Validar condición y motivo
    const condicionDelEquipo = document.getElementById('condicionDelEquipo').value.trim();
    const motivoDeLlamada = document.getElementById('motivoDeLlamada').value.trim();
    if (!condicionDelEquipo || !motivoDeLlamada) {
        alert('Por favor, ingrese la condición del equipo y el motivo de la llamada');
        return;
    }

    //Verifica que el campo del técnico esté completo.
    const tecnico = document.getElementById('tecnico').value.trim();
    if (!tecnico) {
        alert('Por favor, ingrese el nombre del técnico');
        return;
    }

    // Validar firma y sello
    if (!campoFirma.value || !campoSello.value) {
        alert('Por favor, firme y agregue un sello');
        return;
    }
  // evento de envío al formulario
  document.getElementById('formularioDeTicketDeServicio').addEventListener('submit', (e) => {
    e.preventDefault();
    // Envío de formulario y muestra el mensaje de confirmación
    document.getElementById('mensaje-de-confirmacion').style.display = 'block';
  });

    //muestra un mesanje emergente cuando el formulario fue enviado con
    alert('Formulario enviado con éxito!');
});
