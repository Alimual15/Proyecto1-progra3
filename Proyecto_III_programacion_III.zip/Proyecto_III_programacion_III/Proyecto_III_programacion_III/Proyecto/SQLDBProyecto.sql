--BASE DE DATOS 
--Cada tabla creada tiene su propia clave primaria definida con índices cluster.


--Esta instrucción indica al servidor que
-- se use la base de datos master temporalmente para crear la nueva base de datos.
use master
go 

--Crea la base de datos
create DATABASE [DB_Boleta]
go


-- Table infoc infoclient
--infoc para almacenar información relacionada con los clientes.
create table [infoc]
(
cliente int NOT NULL,
idtecnico VARCHAR (15) NOT NULL,
fecha VARCHAR (15) NOT NULL,
modelo VARCHAR (15) NOT NULL,
serie VARCHAR (15) NOT NULL,
boleta_nro VARCHAR (15) NOT NULL,
CONSTRAINT [PK infoclient] PRIMARY KEY CLUSTERED
(
[cliente]
)
)
go

--Table inci incidencia
--inci para almacenar información sobre las incidencias reportadas.
create table [inci]
(
id_N_incidencia int NOT NULL,
M_servicio VARCHAR (15) NOT NULL,
Hra_I_V VARCHAR (15) NOT NULL,
Hra_f_V VARCHAR (15) NOT NULL,
Hra_I_T VARCHAR (15) NOT NULL,
Hra_f_T VARCHAR (15) NOT NULL,
C_equipo VARCHAR (15) NOT NULL,
Acc_Tom VARCHAR (15) NOT NULL,
Mot_Li VARCHAR (15) NOT NULL,
UB_falla VARCHAR (15) NOT NULL,
T_falla VARCHAR (15) NOT NULL,
CONSTRAINT [PK incidencia] PRIMARY KEY CLUSTERED
(
[id_N_incidencia]
)
)
go

--Table res repuestos
--res para almacenar información sobre los repuestos utilizados.
create table [res]
(
id_codigo int NOT NULL,
descripcion VARCHAR (15) NOT NULL,
cantidad VARCHAR (15) NOT NULL,
estado VARCHAR (15) NOT NULL,
CONSTRAINT [PK repuestos] PRIMARY KEY CLUSTERED
(
[id_codigo]
)
)
go

--Table pro proforma
--pro para almacenar información relacionada con proformas.
create table [pro]
(
id_prof_rep int NOT NULL,
Fac_mano_o VARCHAR (15) NOT NULL,
Maq_o VARCHAR (15) NOT NULL,
CONSTRAINT [PK proforma] PRIMARY KEY CLUSTERED
(
[id_prof_rep]
)
)
go
